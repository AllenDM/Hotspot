#!/bin/sh
cd examples/Google\ search
./run.sh
cd ../..